import Vue from 'vue'
import Router from 'vue-router'
import { normalizeURL, decode } from 'ufo'
import { interopDefault } from './utils'
import scrollBehavior from './router.scrollBehavior.js'

const _13ab350b = () => interopDefault(import('..\\pages\\layout\\index.vue' /* webpackChunkName: "" */))
const _2083eef6 = () => interopDefault(import('..\\pages\\home\\index.vue' /* webpackChunkName: "" */))
const _4019f214 = () => interopDefault(import('..\\pages\\login\\index.vue' /* webpackChunkName: "" */))
const _15561f22 = () => interopDefault(import('..\\pages\\setting\\index.vue' /* webpackChunkName: "" */))
const _ae36d230 = () => interopDefault(import('..\\pages\\editor\\index.vue' /* webpackChunkName: "" */))
const _27a9ae09 = () => interopDefault(import('..\\pages\\article\\index.vue' /* webpackChunkName: "" */))
const _fc05d914 = () => interopDefault(import('..\\pages\\profile\\index.vue' /* webpackChunkName: "" */))

const emptyFn = () => {}

Vue.use(Router)

export const routerOptions = {
  mode: 'history',
  base: '/',
  linkActiveClass: 'active',
  linkExactActiveClass: 'nuxt-link-exact-active',
  scrollBehavior,

  routes: [{
    path: "/",
    component: _13ab350b,
    children: [{
      path: "",
      component: _2083eef6,
      name: "home"
    }, {
      path: "/login",
      component: _4019f214,
      name: "login"
    }, {
      path: "/register",
      component: _4019f214,
      name: "register"
    }, {
      path: "/setting",
      component: _15561f22,
      name: "setting"
    }, {
      path: "/editor",
      component: _ae36d230,
      name: "editor"
    }, {
      path: "/article/:slug",
      component: _27a9ae09,
      name: "article"
    }, {
      path: "/profile/:username",
      component: _fc05d914,
      name: "profile"
    }]
  }],

  fallback: false
}

export function createRouter (ssrContext, config) {
  const base = (config.app && config.app.basePath) || routerOptions.base
  const router = new Router({ ...routerOptions, base  })

  // TODO: remove in Nuxt 3
  const originalPush = router.push
  router.push = function push (location, onComplete = emptyFn, onAbort) {
    return originalPush.call(this, location, onComplete, onAbort)
  }

  const resolve = router.resolve.bind(router)
  router.resolve = (to, current, append) => {
    if (typeof to === 'string') {
      to = normalizeURL(to)
    }
    return resolve(to, current, append)
  }

  return router
}
